document.addEventListener("DOMContentLoaded", function () {

    const btn = document.getElementById("predictBtn");

    btn.addEventListener("click", async function () {

        const fileInput = document.getElementById("imageInput");
        const result = document.getElementById("result");

        if (fileInput.files.length === 0) {
            result.innerHTML = "Please select an image.";
            return;
        }

        const formData = new FormData();
        formData.append("file", fileInput.files[0]);

        result.innerHTML = "⏳ Predicting...";

        try {

            const response = await fetch("http://127.0.0.1:8000/predict", {
                method: "POST",
                body: formData
            });

            const data = await response.json();

            result.innerHTML =
                "<h2>Prediction: " + data.prediction + "</h2>" +
                "<p><strong>Confidence:</strong> " + data.confidence + "%</p>";

        } catch (error) {

            console.error(error);

            result.innerHTML =
                "<p style='color:red;'>Failed to connect to the backend.</p>";

        }

    });

});